import {
    loadTodoItems,
    createTodoItem,
    getTodoItem,
    changeTextTodo,
    deleteTodoItem,
} from "./request.js";

import { show, hide } from "./animation.js";

document.addEventListener("DOMContentLoaded", () => {
    const tasksList = document.getElementById("tasksList");
    const button = document.getElementById("button");
    const input = document.getElementById("taskInput");
    const changeBlock = document.querySelector(".task_change");
    tasksList.innerHTML = "";

    // Загрузка существующих задач
    loadTodoItems()
        .then((data) => {
            data.forEach((item) => addTaskToDOM(item));
            window.scrollTo({
                top: document.documentElement.scrollHeight,
                behavior: "smooth",
            });
            document.dispatchEvent(new Event("todosRendered"));
        })
        .catch((err) => console.error("Ошибка:", err));

    // Добавление новой задачи
    button.addEventListener("click", async (e) => {
        e.preventDefault();
        const text = input.value.trim();
        let edited = null;
        if (text.length > 0) {
            if (changeBlock.dataset.visible == "true" && window.currentTodo) {
                const span = window.currentTodo.querySelector("span");
                span.textContent = text;
                changeTextTodo(window.currentTodo.dataset.id, text);

                hide(changeBlock);

                button.classList.remove("active-button");
                input.value = "";

                if (!window.currentTodo.querySelector("p")) {
                    edited = document.createElement("p");
                    edited.textContent = "Ред.";
                    edited.classList.add("todo-edited");
                    window.currentTodo.append(edited);
                }
                return;
            }
            const newTask = await createTodoItem(text);
            addTaskToDOM(newTask, true);
            input.value = "";
            button.classList.remove("active-button");
            window.currentTodo = null;
        }
    });
    // Функция добавления задачи в DOM
    function addTaskToDOM(item, isNewTodo) {
        const listItem = document.createElement("li");

        // Если ТОДО из БД тогда её ненужно отрисовывать
        // Но если пользователь её только создал, её нужно сразу отрисовать
        isNewTodo
            ? listItem.classList.add("task", "show")
            : listItem.classList.add("task");

        listItem.dataset.id = item.id;

        const span = document.createElement("span");
        span.textContent = item.text;

        listItem.append(span);
        tasksList.append(listItem);
        if (item.edited) {
            const edited = document.createElement("p");
            edited.textContent = "Ред.";
            edited.classList.add("todo-edited");
            listItem.append(edited);
        }
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "smooth",
        });
    }
});
